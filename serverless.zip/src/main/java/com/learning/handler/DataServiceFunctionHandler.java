//package com.learning.handler;
//
//import java.util.List;
//
//import org.springframework.cloud.function.adapter.aws.SpringBootRequestHandler;
//
//import com.learning.domain.Data;
//
//
//public class DataServiceFunctionHandler extends SpringBootRequestHandler<Data, List<String>> {
//}
